"use client";
// Mapa onde o usuário escolhe o centro da busca (clicando) e vê o círculo do raio.
import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import type { ClienteAvaliado } from "@/lib/types";

type Props = {
  lat: number;
  lng: number;
  raioKm: number;
  clientes: ClienteAvaliado[];
  selecionado?: string;
  aoMudarCentro: (lat: number, lng: number) => void;
  aoSelecionar: (id: string) => void;
};

export function corPSC(total: number) {
  if (total >= 70) return "var(--alta)";
  if (total >= 40) return "var(--media)";
  return "var(--baixa)";
}

export default function MapaBusca({ lat, lng, raioKm, clientes, selecionado, aoMudarCentro, aoSelecionar }: Props) {
  const divRef = useRef<HTMLDivElement>(null);
  const mapaRef = useRef<L.Map | null>(null);
  const circuloRef = useRef<L.Circle | null>(null);
  const centroRef = useRef<L.Marker | null>(null);
  const camadaRef = useRef<L.LayerGroup | null>(null);
  const aoMudarRef = useRef(aoMudarCentro);
  const aoSelecionarRef = useRef(aoSelecionar);
  aoMudarRef.current = aoMudarCentro;
  aoSelecionarRef.current = aoSelecionar;

  // Cria o mapa uma vez
  useEffect(() => {
    if (!divRef.current || mapaRef.current) return;
    const mapa = L.map(divRef.current, { zoomControl: true }).setView([lat, lng], 12);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: "&copy; OpenStreetMap",
    }).addTo(mapa);

    const iconeCentro = L.divIcon({ className: "pino-centro", html: "<span></span>", iconSize: [22, 22], iconAnchor: [11, 11] });
    centroRef.current = L.marker([lat, lng], { icon: iconeCentro, draggable: true }).addTo(mapa);
    centroRef.current.on("dragend", (e) => {
      const p = (e.target as L.Marker).getLatLng();
      aoMudarRef.current(p.lat, p.lng);
    });
    circuloRef.current = L.circle([lat, lng], {
      radius: raioKm * 1000,
      color: "#0b6e5c",
      weight: 2,
      fillColor: "#0b6e5c",
      fillOpacity: 0.08,
      dashArray: "6 6",
    }).addTo(mapa);
    camadaRef.current = L.layerGroup().addTo(mapa);
    mapa.on("click", (e: L.LeafletMouseEvent) => aoMudarRef.current(e.latlng.lat, e.latlng.lng));
    mapaRef.current = mapa;
    return () => {
      mapa.remove();
      mapaRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Atualiza o centro e o raio
  useEffect(() => {
    const mapa = mapaRef.current;
    if (!mapa || !circuloRef.current || !centroRef.current) return;
    centroRef.current.setLatLng([lat, lng]);
    circuloRef.current.setLatLng([lat, lng]);
    circuloRef.current.setRadius(raioKm * 1000);
    mapa.fitBounds(circuloRef.current.getBounds(), { padding: [24, 24] });
  }, [lat, lng, raioKm]);

  // Desenha os clientes encontrados
  useEffect(() => {
    const camada = camadaRef.current;
    if (!camada) return;
    camada.clearLayers();
    clientes.forEach((c, i) => {
      const cor = getComputedStyle(document.documentElement).getPropertyValue(corPSC(c.psc.total).slice(4, -1)).trim();
      const ativo = c.id === selecionado;
      const icone = L.divIcon({
        className: "pino-cliente" + (ativo ? " ativo" : ""),
        html: `<span style="background:${cor}">${i + 1}</span>`,
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      });
      L.marker([c.lat, c.lng], { icon: icone, title: `${c.nome} — PSC ${c.psc.total}` })
        .on("click", () => aoSelecionarRef.current(c.id))
        .addTo(camada);
    });
  }, [clientes, selecionado]);

  return <div ref={divRef} className="mapa" role="application" aria-label="Mapa: clique para escolher o centro da busca" />;
}
