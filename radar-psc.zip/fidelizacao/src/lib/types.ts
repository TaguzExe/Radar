// Tipos compartilhados entre o servidor e a tela.

export type Local = {
  id: string;
  nome: string;
  endereco: string;
  lat: number;
  lng: number;
  distanciaKm: number;
  nota?: number; // nota no Google (1 a 5)
  avaliacoes?: number; // quantidade de avaliações
  nivelPreco?: string; // INEXPENSIVE, MODERATE, EXPENSIVE...
  site?: string;
  telefone?: string;
  categoria?: string;
  tipos: string[];
  horarios?: string[];
  aberto?: boolean;
  linkMaps?: string;
};

export type CriterioPSC = {
  pontos: number; // 0 a 25
  motivo: string;
};

export type PSC = {
  total: number; // 1 a 100
  potencialVenda: CriterioPSC;
  informacoes: CriterioPSC;
  renda: CriterioPSC;
  interesse: CriterioPSC;
};

export type ClienteAvaliado = Local & {
  psc: PSC;
  resumo: string;
  abordagem: string;
  fontes: string[];
  origemAvaliacao: "ia" | "automatica";
};

export type PedidoBusca = {
  oQueProcura: string; // ex.: "padarias"
  oQueVende: string; // ex.: "café especial em grãos"
  lat: number;
  lng: number;
  raioKm: number;
  quantidade: number; // até 25
};

// Mensagens enviadas do servidor para a tela durante a busca
export type EventoBusca =
  | { tipo: "aviso"; texto: string }
  | { tipo: "locais"; total: number; modo: "google" | "exemplo" }
  | { tipo: "cliente"; cliente: ClienteAvaliado }
  | { tipo: "erro"; texto: string }
  | { tipo: "fim" };
