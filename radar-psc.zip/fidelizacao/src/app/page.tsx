"use client";
import dynamic from "next/dynamic";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { ClienteAvaliado, EventoBusca, PSC } from "@/lib/types";

const MapaBusca = dynamic(() => import("./MapaBusca"), {
  ssr: false,
  loading: () => <div className="mapa mapa-carregando">Carregando mapa…</div>,
});

type Status = "novo" | "contato" | "fiel" | "descartado";
const STATUS: { valor: Status; rotulo: string }[] = [
  { valor: "novo", rotulo: "Novo" },
  { valor: "contato", rotulo: "Em contato" },
  { valor: "fiel", rotulo: "Cliente fiel" },
  { valor: "descartado", rotulo: "Descartado" },
];
type Acompanhamento = Record<string, { status: Status; anotacao: string }>;

const CRITERIOS: { chave: keyof Omit<PSC, "total">; rotulo: string }[] = [
  { chave: "potencialVenda", rotulo: "Potencial de venda" },
  { chave: "informacoes", rotulo: "Informações disponíveis" },
  { chave: "renda", rotulo: "Renda" },
  { chave: "interesse", rotulo: "Interesse comercial" },
];

const faixa = (t: number) => (t >= 70 ? { nome: "Alta", cls: "alta" } : t >= 40 ? { nome: "Média", cls: "media" } : { nome: "Baixa", cls: "baixa" });

function ler<T>(chave: string, padrao: T): T {
  try {
    const v = localStorage.getItem(chave);
    return v ? (JSON.parse(v) as T) : padrao;
  } catch {
    return padrao;
  }
}
function gravar(chave: string, valor: unknown) {
  try {
    localStorage.setItem(chave, JSON.stringify(valor));
  } catch {
    /* navegador sem armazenamento: segue sem salvar */
  }
}

export default function Pagina() {
  const [oQueProcura, setOQueProcura] = useState("padarias");
  const [oQueVende, setOQueVende] = useState("café especial em grãos para revenda");
  const [lat, setLat] = useState(-23.5614);
  const [lng, setLng] = useState(-46.6559);
  const [raioKm, setRaioKm] = useState(3);
  const [quantidade, setQuantidade] = useState(25);
  const [endereco, setEndereco] = useState("");
  const [clientes, setClientes] = useState<ClienteAvaliado[]>([]);
  const [esperados, setEsperados] = useState(0);
  const [buscando, setBuscando] = useState(false);
  const [mensagem, setMensagem] = useState("");
  const [erro, setErro] = useState("");
  const [modo, setModo] = useState<"google" | "exemplo" | null>(null);
  const [config, setConfig] = useState<{ google: boolean; ia: boolean } | null>(null);
  const [selecionado, setSelecionado] = useState<string>();
  const [acomp, setAcomp] = useState<Acompanhamento>({});
  const [filtro, setFiltro] = useState<Status | "todos">("todos");
  const cancelarRef = useRef<AbortController | null>(null);

  useEffect(() => {
    setAcomp(ler("radar-psc-acompanhamento", {}));
    const f = ler<{ oQueProcura?: string; oQueVende?: string; raioKm?: number }>("radar-psc-formulario", {});
    if (f.oQueProcura) setOQueProcura(f.oQueProcura);
    if (f.oQueVende) setOQueVende(f.oQueVende);
    if (f.raioKm) setRaioKm(f.raioKm);
    fetch("/api/local").then((r) => r.json()).then(setConfig).catch(() => setConfig(null));
  }, []);

  const mudarCentro = useCallback((a: number, b: number) => {
    setLat(a);
    setLng(b);
  }, []);

  function usarMinhaLocalizacao() {
    setErro("");
    if (!navigator.geolocation) {
      setErro("Este navegador não informa a localização. Clique no mapa para escolher o ponto.");
      return;
    }
    setMensagem("Pegando sua localização…");
    navigator.geolocation.getCurrentPosition(
      (p) => {
        mudarCentro(p.coords.latitude, p.coords.longitude);
        setMensagem("Centro da busca: sua localização atual.");
      },
      () => {
        setMensagem("");
        setErro("Não foi possível pegar sua localização. Permita o acesso no navegador ou clique no mapa.");
      },
      { enableHighAccuracy: true, timeout: 10000 },
    );
  }

  async function irParaEndereco(e: React.FormEvent) {
    e.preventDefault();
    if (!endereco.trim()) return;
    setErro("");
    const r = await fetch(`/api/local?q=${encodeURIComponent(endereco)}`);
    const d = await r.json();
    if (!r.ok) return setErro(d.erro ?? "Endereço não encontrado.");
    mudarCentro(d.lat, d.lng);
    setMensagem(`Centro da busca: ${d.endereco}`);
  }

  async function buscar(e: React.FormEvent) {
    e.preventDefault();
    if (!oQueProcura.trim()) return setErro("Escreva que tipo de cliente você procura.");
    cancelarRef.current?.abort();
    const ctrl = new AbortController();
    cancelarRef.current = ctrl;
    gravar("radar-psc-formulario", { oQueProcura, oQueVende, raioKm });
    setClientes([]);
    setEsperados(0);
    setErro("");
    setSelecionado(undefined);
    setBuscando(true);
    setMensagem("Começando a busca…");

    try {
      const resp = await fetch("/api/buscar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ oQueProcura, oQueVende, lat, lng, raioKm, quantidade }),
        signal: ctrl.signal,
      });
      if (!resp.ok || !resp.body) {
        const d = await resp.json().catch(() => ({}));
        throw new Error(d.erro ?? "A busca falhou. Tente de novo.");
      }
      const leitor = resp.body.getReader();
      const dec = new TextDecoder();
      let resto = "";
      for (;;) {
        const { value, done } = await leitor.read();
        if (done) break;
        resto += dec.decode(value, { stream: true });
        const linhas = resto.split("\n");
        resto = linhas.pop() ?? "";
        for (const linha of linhas) {
          if (!linha.trim()) continue;
          const ev = JSON.parse(linha) as EventoBusca;
          if (ev.tipo === "aviso") setMensagem(ev.texto);
          else if (ev.tipo === "locais") {
            setEsperados(ev.total);
            setModo(ev.modo);
          } else if (ev.tipo === "cliente") setClientes((atual) => [...atual, ev.cliente]);
          else if (ev.tipo === "erro") setErro(ev.texto);
          else if (ev.tipo === "fim") setMensagem("Busca concluída.");
        }
      }
    } catch (err) {
      if ((err as Error).name !== "AbortError") setErro((err as Error).message);
    } finally {
      setBuscando(false);
    }
  }

  function atualizarAcomp(id: string, mudanca: Partial<{ status: Status; anotacao: string }>) {
    setAcomp((atual) => {
      const base = atual[id] ?? { status: "novo" as Status, anotacao: "" };
      const novo = { ...atual, [id]: { ...base, ...mudanca } };
      gravar("radar-psc-acompanhamento", novo);
      return novo;
    });
  }

  const ordenados = useMemo(() => [...clientes].sort((a, b) => b.psc.total - a.psc.total), [clientes]);
  const visiveis = ordenados.filter((c) => filtro === "todos" || (acomp[c.id]?.status ?? "novo") === filtro);
  const media = clientes.length ? Math.round(clientes.reduce((s, c) => s + c.psc.total, 0) / clientes.length) : 0;
  const altas = clientes.filter((c) => c.psc.total >= 70).length;

  function exportarPlanilha() {
    const cab = ["Posição", "Nome", "PSC", "Potencial de venda", "Informações", "Renda", "Interesse", "Telefone", "Site", "Endereço", "Distância (km)", "Status", "Anotação", "Resumo", "Abordagem"];
    const linhas = ordenados.map((c, i) => [
      i + 1, c.nome, c.psc.total, c.psc.potencialVenda.pontos, c.psc.informacoes.pontos, c.psc.renda.pontos, c.psc.interesse.pontos,
      c.telefone ?? "", c.site ?? "", c.endereco, c.distanciaKm,
      STATUS.find((s) => s.valor === (acomp[c.id]?.status ?? "novo"))?.rotulo, acomp[c.id]?.anotacao ?? "", c.resumo, c.abordagem,
    ]);
    const csv = [cab, ...linhas].map((l) => l.map((v) => `"${String(v ?? "").replace(/"/g, '""')}"`).join(";")).join("\n");
    const url = URL.createObjectURL(new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `clientes-psc-${oQueProcura.replace(/\W+/g, "-")}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="pagina">
      <header className="topo">
        <div className="marca">
          <span className="marca-icone" aria-hidden="true">
            <svg viewBox="0 0 32 32" width="28" height="28"><circle cx="16" cy="16" r="13" fill="none" stroke="currentColor" strokeWidth="2.5" strokeDasharray="4 3" /><circle cx="16" cy="16" r="4.5" fill="currentColor" /></svg>
          </span>
          <div>
            <h1>Radar PSC</h1>
            <p>Encontre, avalie e fidelize clientes perto de você</p>
          </div>
        </div>
        {config && (
          <div className="ligados">
            <span className={config.google ? "chip ok" : "chip off"}>Google Maps {config.google ? "ligado" : "desligado"}</span>
            <span className={config.ia ? "chip ok" : "chip off"}>Pesquisa com IA {config.ia ? "ligada" : "desligada"}</span>
          </div>
        )}
      </header>

      <main className="grade">
        <section className="painel" aria-label="Busca">
          <form onSubmit={buscar} className="formulario">
            <label htmlFor="procura">Que tipo de cliente você procura?</label>
            <input id="procura" value={oQueProcura} onChange={(e) => setOQueProcura(e.target.value)} placeholder="ex.: academias, clínicas odontológicas" />

            <label htmlFor="vende">O que você vende para eles?</label>
            <textarea id="vende" rows={2} value={oQueVende} onChange={(e) => setOQueVende(e.target.value)} placeholder="ex.: sistema de agendamento, uniformes, produtos de limpeza" />

            <fieldset className="local">
              <legend>Onde procurar</legend>
              <button type="button" className="botao-sec" onClick={usarMinhaLocalizacao}>
                Usar minha localização
              </button>
              <div className="linha-endereco">
                <input id="endereco" aria-label="Cidade ou endereço" value={endereco} onChange={(e) => setEndereco(e.target.value)} placeholder="ou digite cidade/bairro" onKeyDown={(e) => e.key === "Enter" && irParaEndereco(e)} />
                <button type="button" className="botao-sec" onClick={irParaEndereco}>Ir</button>
              </div>
              <p className="dica">Você também pode clicar no mapa ou arrastar o ponto central.</p>

              <label htmlFor="raio">
                Distância máxima: <strong className="num">{raioKm} km</strong>
              </label>
              <input id="raio" type="range" min={0.5} max={50} step={0.5} value={raioKm} onChange={(e) => setRaioKm(Number(e.target.value))} />
            </fieldset>

            <label htmlFor="qtd">
              Quantos clientes mostrar: <strong className="num">{quantidade}</strong>
            </label>
            <input id="qtd" type="range" min={5} max={25} step={1} value={quantidade} onChange={(e) => setQuantidade(Number(e.target.value))} />

            <button type="submit" className="botao" disabled={buscando}>
              {buscando ? "Buscando…" : "Buscar e avaliar clientes"}
            </button>
          </form>
          <div className="estado" aria-live="polite">
            {mensagem && <p className="mensagem">{mensagem}</p>}
            {buscando && esperados > 0 && (
              <div className="progresso" role="progressbar" aria-valuemin={0} aria-valuemax={esperados} aria-valuenow={clientes.length}>
                <span style={{ width: `${(clientes.length / esperados) * 100}%` }} />
                <em className="num">{clientes.length}/{esperados} avaliados</em>
              </div>
            )}
            {erro && <p className="erro">{erro}</p>}
          </div>
        </section>

        <section className="area-mapa" aria-label="Mapa">
          <MapaBusca lat={lat} lng={lng} raioKm={raioKm} clientes={ordenados} selecionado={selecionado} aoMudarCentro={mudarCentro} aoSelecionar={(id) => {
            setSelecionado(id);
            document.getElementById(`cliente-${id}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
          }} />
        </section>
      </main>

      <section className="resultados" aria-label="Clientes avaliados">
        {modo === "exemplo" && clientes.length > 0 && (
          <p className="faixa-exemplo">Estes são <strong>locais de exemplo</strong>, só para mostrar como o app funciona. Coloque a chave do Google Maps para ver estabelecimentos reais.</p>
        )}

        {clientes.length > 0 ? (
          <>
            <div className="resumo-busca">
              <div><span className="num grande">{clientes.length}</span><small>clientes avaliados</small></div>
              <div><span className="num grande">{media}</span><small>PSC médio</small></div>
              <div><span className="num grande">{altas}</span><small>com PSC alto (70+)</small></div>
              <div className="acoes">
                <select aria-label="Filtrar por status" value={filtro} onChange={(e) => setFiltro(e.target.value as Status | "todos")}>
                  <option value="todos">Todos os status</option>
                  {STATUS.map((s) => <option key={s.valor} value={s.valor}>{s.rotulo}</option>)}
                </select>
                <button className="botao-sec" onClick={exportarPlanilha}>Baixar planilha</button>
              </div>
            </div>

            <ol className="lista">
              {visiveis.map((c) => {
                const pos = ordenados.indexOf(c) + 1;
                const f = faixa(c.psc.total);
                const a = acomp[c.id] ?? { status: "novo", anotacao: "" };
                return (
                  <li key={c.id} id={`cliente-${c.id}`} className={`cartao ${c.id === selecionado ? "selecionado" : ""}`} onClick={() => setSelecionado(c.id)}>
                    <div className="cartao-topo">
                      <span className="posicao num">{pos}</span>
                      <div className="cartao-nome">
                        <h3>{c.nome}</h3>
                        <p>{[c.categoria, `${c.distanciaKm} km`, c.nota ? `★ ${c.nota.toFixed(1)} (${c.avaliacoes ?? 0})` : null].filter(Boolean).join(" · ")}</p>
                      </div>
                      <div className={`psc ${f.cls}`} title="Percentual de Sucesso Comercial">
                        <svg viewBox="0 0 44 44" aria-hidden="true">
                          <circle cx="22" cy="22" r="19" className="anel-fundo" />
                          <circle cx="22" cy="22" r="19" className="anel" strokeDasharray={`${(c.psc.total / 100) * 119.4} 119.4`} />
                        </svg>
                        <span className="num">{c.psc.total}</span>
                        <small>PSC {f.nome}</small>
                      </div>
                    </div>

                    <div className="criterios">
                      {CRITERIOS.map(({ chave, rotulo }) => (
                        <div key={chave} className="criterio" title={c.psc[chave].motivo}>
                          <div className="criterio-rotulo"><span>{rotulo}</span><span className="num">{c.psc[chave].pontos}/25</span></div>
                          <div className="barra"><span style={{ width: `${(c.psc[chave].pontos / 25) * 100}%` }} /></div>
                          <p>{c.psc[chave].motivo}</p>
                        </div>
                      ))}
                    </div>

                    {c.resumo && <p className="texto-resumo">{c.resumo}</p>}
                    {c.abordagem && <p className="abordagem"><strong>Como abordar:</strong> {c.abordagem}</p>}

                    <div className="contato">
                      {c.telefone && <span className="num selecionavel">{c.telefone}</span>}
                      {c.site && <a href={c.site} target="_blank" rel="noreferrer">Site</a>}
                      {c.linkMaps && <a href={c.linkMaps} target="_blank" rel="noreferrer">Ver no Google Maps</a>}
                      {c.fontes.filter((u) => u !== c.linkMaps).slice(0, 3).map((u) => (
                        <a key={u} href={u} target="_blank" rel="noreferrer" className="fonte">{new URL(u).hostname.replace("www.", "")}</a>
                      ))}
                      <span className={`origem ${c.origemAvaliacao}`}>{c.origemAvaliacao === "ia" ? "Avaliado com pesquisa na internet" : "Avaliação automática"}</span>
                    </div>

                    <div className="acompanhamento" onClick={(e) => e.stopPropagation()}>
                      <select aria-label={`Status de ${c.nome}`} value={a.status} onChange={(e) => atualizarAcomp(c.id, { status: e.target.value as Status })} className={`status ${a.status}`}>
                        {STATUS.map((s) => <option key={s.valor} value={s.valor}>{s.rotulo}</option>)}
                      </select>
                      <input aria-label={`Anotação sobre ${c.nome}`} placeholder="Anotação (ex.: ligar na terça)" value={a.anotacao} onChange={(e) => atualizarAcomp(c.id, { anotacao: e.target.value })} />
                    </div>
                  </li>
                );
              })}
            </ol>
          </>
        ) : (
          !buscando && (
            <div className="vazio">
              <h2>Como funciona</h2>
              <ol>
                <li>Diga que tipo de cliente procura e o que você vende.</li>
                <li>Escolha o centro no mapa (ou use sua localização) e a distância máxima.</li>
                <li>O app busca no Google Maps, pesquisa cada cliente na internet e dá o <strong>PSC</strong>, uma nota de 1 a 100.</li>
              </ol>
              <p>O PSC soma 4 critérios de até 25 pontos: potencial de venda, informações disponíveis, renda e interesse comercial no contexto.</p>
            </div>
          )
        )}
      </section>
    </div>
  );
}
