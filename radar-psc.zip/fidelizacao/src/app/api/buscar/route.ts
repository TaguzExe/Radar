// Recebe o pedido da tela, busca no Google Maps, pesquisa cada cliente na internet,
// calcula o PSC e envia os resultados aos poucos (para a tela ir mostrando).
import { locaisDeExemplo } from "@/lib/exemplo";
import { buscarLocais, temChaveGoogle } from "@/lib/places";
import { pesquisarCliente, temChaveIA } from "@/lib/pesquisa";
import { pscAutomatico } from "@/lib/psc";
import type { ClienteAvaliado, EventoBusca, Local, PedidoBusca } from "@/lib/types";

export const maxDuration = 300;
export const dynamic = "force-dynamic";

const PESQUISAS_AO_MESMO_TEMPO = 5;

export async function POST(req: Request) {
  let pedido: PedidoBusca;
  try {
    pedido = await req.json();
  } catch {
    return Response.json({ erro: "Pedido inválido." }, { status: 400 });
  }

  const oQueProcura = String(pedido.oQueProcura ?? "").trim().slice(0, 200);
  const oQueVende = String(pedido.oQueVende ?? "").trim().slice(0, 300);
  const lat = Number(pedido.lat);
  const lng = Number(pedido.lng);
  const raioKm = Math.min(Math.max(Number(pedido.raioKm) || 5, 0.5), 50);
  const quantidade = Math.min(Math.max(Math.round(Number(pedido.quantidade) || 25), 1), 25);

  if (!oQueProcura || !Number.isFinite(lat) || !Number.isFinite(lng)) {
    return Response.json({ erro: "Informe o que procurar e a localização." }, { status: 400 });
  }

  const codificador = new TextEncoder();
  const fluxo = new ReadableStream({
    async start(controle) {
      const enviar = (e: EventoBusca) => controle.enqueue(codificador.encode(JSON.stringify(e) + "\n"));

      try {
        let locais: Local[];
        const modo = temChaveGoogle() ? "google" : "exemplo";
        if (modo === "google") {
          enviar({ tipo: "aviso", texto: "Buscando no Google Maps..." });
          locais = await buscarLocais(oQueProcura, lat, lng, raioKm, quantidade);
        } else {
          enviar({ tipo: "aviso", texto: "Sem chave do Google Maps: mostrando locais de exemplo." });
          locais = locaisDeExemplo(oQueProcura, lat, lng, raioKm, quantidade);
        }

        // Pré-seleção: os mais promissores pelo cálculo automático, até o limite pedido
        const preSelecionados = locais
          .map((l) => ({ l, psc: pscAutomatico(l, oQueProcura, raioKm) }))
          .sort((a, b) => b.psc.total - a.psc.total)
          .slice(0, quantidade);

        enviar({ tipo: "locais", total: preSelecionados.length, modo });
        if (preSelecionados.length === 0) {
          enviar({ tipo: "aviso", texto: "Nenhum local encontrado nesse círculo. Aumente a distância ou mude o termo." });
        }

        const usarIA = temChaveIA() && modo === "google";
        if (usarIA) enviar({ tipo: "aviso", texto: "Pesquisando cada cliente na internet com IA..." });

        let proximo = 0;
        const trabalhar = async () => {
          while (proximo < preSelecionados.length) {
            const { l, psc } = preSelecionados[proximo++];
            let avaliado: ClienteAvaliado = {
              ...l,
              psc,
              resumo: [l.categoria, l.endereco].filter(Boolean).join(" · "),
              abordagem: "",
              fontes: l.linkMaps ? [l.linkMaps] : [],
              origemAvaliacao: "automatica",
            };
            if (usarIA) {
              try {
                const r = await pesquisarCliente(l, oQueProcura, oQueVende);
                if (r) {
                  avaliado = { ...avaliado, ...r, fontes: [...avaliado.fontes, ...r.fontes], origemAvaliacao: "ia" };
                }
              } catch (e) {
                console.error("Falha na pesquisa com IA:", e);
              }
            }
            enviar({ tipo: "cliente", cliente: avaliado });
          }
        };
        await Promise.all(Array.from({ length: usarIA ? PESQUISAS_AO_MESMO_TEMPO : 1 }, trabalhar));
        enviar({ tipo: "fim" });
      } catch (e) {
        enviar({ tipo: "erro", texto: e instanceof Error ? e.message : "Erro inesperado na busca." });
      } finally {
        controle.close();
      }
    },
  });

  return new Response(fluxo, {
    headers: { "Content-Type": "application/x-ndjson; charset=utf-8", "Cache-Control": "no-store" },
  });
}
