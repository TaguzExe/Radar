# Radar PSC: app de fidelização de clientes

O app procura clientes no **Google Maps** dentro do círculo que você escolher (sua localização ou um ponto no mapa, com distância de 0,5 a 50 km). Depois **pesquisa cada um na internet** com IA e mostra **até 25 clientes**, do melhor para o pior pelo **PSC (Percentual de Sucesso Comercial)**, uma nota de 1 a 100.

## Como o PSC é calculado
São 4 critérios, e cada um vale até 25 pontos. A soma dá a nota de 1 a 100:

| Critério | O que mede |
|---|---|
| Potencial de venda | Chance de comprar e volume possível (porte, movimento, avaliações) |
| Informações disponíveis | Site, telefone, redes sociais, responsável, horários |
| Renda | Capacidade financeira estimada (faixa de preço, bairro, porte) |
| Interesse comercial no contexto | O quanto o que **você** vende combina com este cliente agora |

- PSC **70 ou mais**: alto (verde). **40 a 69**: médio (amarelo). **Abaixo de 40**: baixo (vermelho).
- Com a IA ligada, cada nota vem com o motivo e uma sugestão de **como abordar e fidelizar** o cliente.
- Para cada cliente você marca o status (Novo, Em contato, Cliente fiel, Descartado), escreve anotações e pode **baixar tudo numa planilha**.

## As duas chaves (senhas de acesso)
| Chave | Para que serve | Onde conseguir |
|---|---|---|
| `GOOGLE_MAPS_API_KEY` | Buscar os estabelecimentos reais no Google Maps | console.cloud.google.com: crie um projeto, ative a **"Places API (New)"** e crie uma chave em "Credenciais". O Google pede um cartão e tem uma cota gratuita por mês. |
| `ANTHROPIC_API_KEY` | Pesquisar cada cliente na internet e dar o PSC | console.anthropic.com: em "API Keys", crie uma chave e coloque créditos. |

Sem as chaves, o app mostra **locais de exemplo** para você ver como funciona. Só com a chave do Google, ele busca locais reais e calcula o PSC de forma automática, sem pesquisa na internet. Com as duas chaves, ele faz a avaliação completa.

## Colocar no ar (sem programar), pela Vercel
1. Crie uma conta grátis em github.com e outra em vercel.com (dá para entrar na Vercel usando o GitHub).
2. Envie esta pasta para um repositório no GitHub. O Claude pode fazer isso por você.
3. Na Vercel, clique em **Add New → Project**, escolha o repositório e, em **Environment Variables**, adicione as duas chaves acima.
4. Clique em **Deploy**. Em cerca de 2 minutos você recebe um endereço (ex.: `radar-psc.vercel.app`) que abre no computador e no celular.

## Rodar no seu computador (opcional)
Instale o Node.js (nodejs.org). Depois, dentro desta pasta, rode:
```
npm install
cp .env.example .env.local   (e cole as chaves no .env.local)
npm run dev
```
e abra http://localhost:3000

## Onde fica cada parte
- `src/app/page.tsx`: a tela
- `src/app/MapaBusca.tsx`: o mapa com o círculo de busca
- `src/lib/places.ts`: a busca no Google Maps
- `src/lib/pesquisa.ts`: a pesquisa na internet com IA e as notas do PSC
- `src/lib/psc.ts`: o cálculo automático do PSC (usado quando a IA está desligada)
