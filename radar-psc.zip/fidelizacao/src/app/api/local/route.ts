// Converte o nome de uma cidade/endereço em coordenadas e informa o que está ligado.
import { localizarEndereco, temChaveGoogle } from "@/lib/places";
import { temChaveIA } from "@/lib/pesquisa";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const q = new URL(req.url).searchParams.get("q")?.trim();
  if (!q) {
    return Response.json({ google: temChaveGoogle(), ia: temChaveIA() });
  }
  if (!temChaveGoogle()) {
    return Response.json(
      { erro: "Para procurar endereços é preciso a chave do Google Maps. Por enquanto, clique no mapa ou use sua localização." },
      { status: 400 },
    );
  }
  try {
    const r = await localizarEndereco(q.slice(0, 200));
    if (!r) return Response.json({ erro: "Endereço não encontrado." }, { status: 404 });
    return Response.json(r);
  } catch (e) {
    return Response.json({ erro: e instanceof Error ? e.message : "Erro ao procurar endereço." }, { status: 500 });
  }
}
