// Cálculo do PSC (Percentual de Sucesso Comercial), nota de 1 a 100.
// São 4 critérios, cada um vale de 0 a 25 pontos:
//   1. Potencial de venda
//   2. Informações disponíveis
//   3. Renda
//   4. Interesse comercial no contexto
// Este arquivo tem o cálculo automático (sem IA), usado quando a IA não está ligada
// ou não conseguiu responder. Com a IA ligada, ela pesquisa na internet e dá as notas.
import type { CriterioPSC, Local, PSC } from "./types";

const limitar = (n: number, min: number, max: number) => Math.max(min, Math.min(max, n));

export function montarPSC(p: number, i: number, r: number, c: number, motivos: [string, string, string, string]): PSC {
  const crit = (pontos: number, motivo: string): CriterioPSC => ({ pontos: Math.round(limitar(pontos, 0, 25)), motivo });
  const potencialVenda = crit(p, motivos[0]);
  const informacoes = crit(i, motivos[1]);
  const renda = crit(r, motivos[2]);
  const interesse = crit(c, motivos[3]);
  const total = limitar(potencialVenda.pontos + informacoes.pontos + renda.pontos + interesse.pontos, 1, 100);
  return { total, potencialVenda, informacoes, renda, interesse };
}

const normalizar = (s: string) =>
  s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");

export function pscAutomatico(local: Local, oQueProcura: string, raioKm: number): PSC {
  // 1. Potencial de venda: movimento do negócio (avaliações) e reputação
  const av = local.avaliacoes ?? 0;
  let potencial = Math.min(15, Math.log10(av + 1) * 5.5);
  if ((local.nota ?? 0) >= 4.2) potencial += 5;
  else if ((local.nota ?? 0) >= 3.5) potencial += 3;
  if (local.aberto) potencial += 5;

  // 2. Informações disponíveis
  let info = 0;
  const tem: string[] = [];
  if (local.site) { info += 7; tem.push("site"); }
  if (local.telefone) { info += 6; tem.push("telefone"); }
  if (local.nota) { info += 4; tem.push("nota no Google"); }
  if (local.horarios?.length) { info += 4; tem.push("horários"); }
  if (av >= 20) { info += 4; tem.push(`${av} avaliações`); }

  // 3. Renda (estimada pelo nível de preço do Google)
  const tabelaPreco: Record<string, [number, string]> = {
    PRICE_LEVEL_FREE: [5, "gratuito"],
    PRICE_LEVEL_INEXPENSIVE: [9, "barato ($)"],
    PRICE_LEVEL_MODERATE: [15, "moderado ($$)"],
    PRICE_LEVEL_EXPENSIVE: [21, "caro ($$$)"],
    PRICE_LEVEL_VERY_EXPENSIVE: [25, "muito caro ($$$$)"],
  };
  const preco = local.nivelPreco ? tabelaPreco[local.nivelPreco] : undefined;
  let renda = preco ? preco[0] : 11;
  if (!preco && av > 300) renda += 3; // negócio movimentado tende a faturar mais

  // 4. Interesse comercial no contexto: o quanto combina com o que foi pedido e a proximidade
  const palavras = normalizar(oQueProcura).split(/\s+/).filter((w) => w.length > 3);
  const textoLocal = normalizar(`${local.nome} ${local.categoria ?? ""} ${local.tipos.join(" ")}`);
  const combina = palavras.some((w) => textoLocal.includes(w.slice(0, Math.max(4, w.length - 2))));
  let interesse = 10;
  if (combina) interesse += 9;
  const perto = local.distanciaKm <= raioKm * 0.35;
  if (perto) interesse += 6;
  else if (local.distanciaKm <= raioKm * 0.7) interesse += 3;

  return montarPSC(potencial, info, renda, interesse, [
    av > 0
      ? `${av} avaliações no Google${local.nota ? `, nota ${local.nota.toFixed(1)}` : ""}${local.aberto ? ", funcionando" : ""}.`
      : "Poucas avaliações no Google; movimento difícil de medir.",
    tem.length ? `Encontrado: ${tem.join(", ")}.` : "Quase nenhuma informação pública.",
    preco ? `Nível de preço ${preco[1]} no Google.` : "Nível de preço não informado; estimativa média.",
    `${combina ? "Combina com o tipo de cliente procurado" : "Combinação parcial com o pedido"}; a ${local.distanciaKm} km do centro da busca.`,
  ]);
}
