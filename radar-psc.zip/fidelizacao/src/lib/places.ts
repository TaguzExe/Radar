// Busca de estabelecimentos no Google Maps (Places API - versão nova).
import { distanciaKm } from "./geo";
import type { Local } from "./types";

const URL_BUSCA = "https://places.googleapis.com/v1/places:searchText";

const CAMPOS = [
  "places.id",
  "places.displayName",
  "places.formattedAddress",
  "places.location",
  "places.rating",
  "places.userRatingCount",
  "places.priceLevel",
  "places.websiteUri",
  "places.nationalPhoneNumber",
  "places.types",
  "places.primaryTypeDisplayName",
  "places.businessStatus",
  "places.googleMapsUri",
  "places.regularOpeningHours.weekdayDescriptions",
  "nextPageToken",
].join(",");

type LugarGoogle = {
  id: string;
  displayName?: { text: string };
  formattedAddress?: string;
  location?: { latitude: number; longitude: number };
  rating?: number;
  userRatingCount?: number;
  priceLevel?: string;
  websiteUri?: string;
  nationalPhoneNumber?: string;
  types?: string[];
  primaryTypeDisplayName?: { text: string };
  businessStatus?: string;
  googleMapsUri?: string;
  regularOpeningHours?: { weekdayDescriptions?: string[] };
};

export function temChaveGoogle(): boolean {
  return Boolean(process.env.GOOGLE_MAPS_API_KEY);
}

async function chamarGoogle(corpo: object, campos: string) {
  const resp = await fetch(URL_BUSCA, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Goog-Api-Key": process.env.GOOGLE_MAPS_API_KEY!,
      "X-Goog-FieldMask": campos,
    },
    body: JSON.stringify(corpo),
  });
  if (!resp.ok) {
    const texto = await resp.text();
    throw new Error(`O Google Maps recusou a busca (${resp.status}). Confira a chave GOOGLE_MAPS_API_KEY. Detalhe: ${texto.slice(0, 300)}`);
  }
  return (await resp.json()) as { places?: LugarGoogle[]; nextPageToken?: string };
}

/** Busca estabelecimentos dentro do círculo (centro + raio). */
export async function buscarLocais(
  oQueProcura: string,
  lat: number,
  lng: number,
  raioKm: number,
  limite: number,
): Promise<Local[]> {
  const raioMetros = Math.min(Math.max(raioKm, 0.5), 50) * 1000; // o Google aceita até 50 km
  const encontrados = new Map<string, Local>();
  let pageToken: string | undefined;

  for (let pagina = 0; pagina < 3; pagina++) {
    const dados = await chamarGoogle(
      {
        textQuery: oQueProcura,
        languageCode: "pt-BR",
        regionCode: "BR",
        pageSize: 20,
        locationBias: { circle: { center: { latitude: lat, longitude: lng }, radius: raioMetros } },
        ...(pageToken ? { pageToken } : {}),
      },
      CAMPOS,
    );

    for (const p of dados.places ?? []) {
      if (!p.location || p.businessStatus === "CLOSED_PERMANENTLY") continue;
      const d = distanciaKm(lat, lng, p.location.latitude, p.location.longitude);
      if (d > raioKm) continue; // fora do círculo escolhido
      encontrados.set(p.id, {
        id: p.id,
        nome: p.displayName?.text ?? "Sem nome",
        endereco: p.formattedAddress ?? "",
        lat: p.location.latitude,
        lng: p.location.longitude,
        distanciaKm: Math.round(d * 10) / 10,
        nota: p.rating,
        avaliacoes: p.userRatingCount,
        nivelPreco: p.priceLevel,
        site: p.websiteUri,
        telefone: p.nationalPhoneNumber,
        categoria: p.primaryTypeDisplayName?.text,
        tipos: p.types ?? [],
        horarios: p.regularOpeningHours?.weekdayDescriptions,
        aberto: p.businessStatus === "OPERATIONAL",
        linkMaps: p.googleMapsUri,
      });
    }

    pageToken = dados.nextPageToken;
    if (!pageToken || encontrados.size >= limite * 2) break;
    await new Promise((r) => setTimeout(r, 1500)); // o Google pede uma pausa antes da próxima página
  }

  return [...encontrados.values()];
}

/** Converte um endereço ou nome de cidade em coordenadas. */
export async function localizarEndereco(texto: string) {
  const dados = await chamarGoogle(
    { textQuery: texto, languageCode: "pt-BR", regionCode: "BR", pageSize: 1 },
    "places.location,places.formattedAddress",
  );
  const p = dados.places?.[0];
  if (!p?.location) return null;
  return { lat: p.location.latitude, lng: p.location.longitude, endereco: p.formattedAddress ?? texto };
}
