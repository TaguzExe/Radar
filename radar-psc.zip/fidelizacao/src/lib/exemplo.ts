// Locais de EXEMPLO, usados só quando ainda não existe chave do Google Maps.
// Servem para ver como o app funciona. Não são estabelecimentos reais.
import { distanciaKm } from "./geo";
import type { Local } from "./types";

const NOMES = ["Aurora", "Bela Vista", "Central", "do Bairro", "Estrela", "Fortaleza", "Girassol", "Horizonte", "Ipê", "Jardim", "Lua Nova", "Mirante", "Nascente", "Oásis", "Primavera"];
const PRECOS = ["PRICE_LEVEL_INEXPENSIVE", "PRICE_LEVEL_MODERATE", "PRICE_LEVEL_EXPENSIVE", undefined, "PRICE_LEVEL_MODERATE"];

function aleatorio(semente: number) {
  let s = semente;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

export function locaisDeExemplo(oQueProcura: string, lat: number, lng: number, raioKm: number, qtd: number): Local[] {
  const rnd = aleatorio(Math.abs(Math.round(lat * 1000 + lng * 1000)) + oQueProcura.length + 7);
  const tipo = oQueProcura.trim().replace(/s$/i, "") || "Comércio";
  const titulo = tipo.charAt(0).toUpperCase() + tipo.slice(1);

  return Array.from({ length: Math.min(qtd, NOMES.length) }, (_, i) => {
    const ang = rnd() * Math.PI * 2;
    const dist = Math.sqrt(rnd()) * raioKm * 0.95;
    const pLat = lat + (dist / 111) * Math.cos(ang);
    const pLng = lng + (dist / (111 * Math.cos((lat * Math.PI) / 180))) * Math.sin(ang);
    const avaliacoes = Math.round(rnd() ** 2 * 900);
    return {
      id: `exemplo-${i}`,
      nome: `${titulo} ${NOMES[i]} (exemplo)`,
      endereco: `Endereço de exemplo, ${Math.round(rnd() * 2000)}`,
      lat: pLat,
      lng: pLng,
      distanciaKm: Math.round(distanciaKm(lat, lng, pLat, pLng) * 10) / 10,
      nota: avaliacoes ? Math.round((3.4 + rnd() * 1.6) * 10) / 10 : undefined,
      avaliacoes,
      nivelPreco: PRECOS[i % PRECOS.length],
      site: rnd() > 0.45 ? "https://example.com" : undefined,
      telefone: rnd() > 0.3 ? "(00) 0000-0000" : undefined,
      categoria: titulo,
      tipos: [oQueProcura],
      horarios: rnd() > 0.4 ? ["Segunda a sábado: 8h às 18h"] : undefined,
      aberto: rnd() > 0.1,
    } satisfies Local;
  });
}
