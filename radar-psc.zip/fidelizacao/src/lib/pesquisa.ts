// Pesquisa na internet sobre cada cliente usando o Claude (IA da Anthropic)
// com a ferramenta de busca na web. Devolve as notas do PSC com justificativa.
import Anthropic from "@anthropic-ai/sdk";
import { z } from "zod";
import { montarPSC } from "./psc";
import type { Local, PSC } from "./types";

export function temChaveIA(): boolean {
  return Boolean(process.env.ANTHROPIC_API_KEY);
}

const Criterio = z.object({ pontos: z.coerce.number(), motivo: z.string() });
const Resposta = z.object({
  resumo: z.string(),
  potencialVenda: Criterio,
  informacoes: Criterio,
  renda: Criterio,
  interesse: Criterio,
  abordagem: z.string(),
  fontes: z.array(z.string()).default([]),
});

export type ResultadoPesquisa = {
  psc: PSC;
  resumo: string;
  abordagem: string;
  fontes: string[];
};

const INSTRUCOES = `Você é um analista comercial brasileiro. Sua tarefa é avaliar um possível cliente para uma empresa que quer vender e fidelizar clientes.

Pesquise na internet (site do estabelecimento, redes sociais, avaliações, notícias, CNPJ, bairro) e dê o PSC - Percentual de Sucesso Comercial. O PSC tem 4 critérios, cada um de 0 a 25 pontos:
1. potencialVenda: chance real de comprar e volume que pode comprar (porte, movimento, número de unidades, crescimento).
2. informacoes: quanta informação útil e confiável existe para abordar o cliente (contatos, site, redes sociais, responsável, horários).
3. renda: capacidade financeira estimada do negócio e do público dele (faixa de preço, bairro, porte, faturamento aparente).
4. interesse: o quanto o produto do vendedor faz sentido para este cliente agora, no contexto dele.

Seja realista: não invente fatos. Quando não achar algo, diga isso no motivo e dê nota menor em "informacoes".
Faça no máximo 3 buscas. Escreva tudo em português do Brasil, frases curtas.

Termine a resposta com UM bloco JSON, sem texto depois dele, neste formato:
{"resumo": "2 ou 3 frases sobre o cliente", "potencialVenda": {"pontos": 0, "motivo": "..."}, "informacoes": {"pontos": 0, "motivo": "..."}, "renda": {"pontos": 0, "motivo": "..."}, "interesse": {"pontos": 0, "motivo": "..."}, "abordagem": "como abordar e fidelizar este cliente, em 2 frases", "fontes": ["url1", "url2"]}`;

function extrairJSON(texto: string): unknown {
  const inicio = texto.lastIndexOf("{\"resumo\"");
  const de = inicio >= 0 ? inicio : texto.indexOf("{");
  const ate = texto.lastIndexOf("}");
  if (de < 0 || ate <= de) return null;
  try {
    return JSON.parse(texto.slice(de, ate + 1));
  } catch {
    return null;
  }
}

let cliente: Anthropic | null = null;

export async function pesquisarCliente(
  local: Local,
  oQueProcura: string,
  oQueVende: string,
): Promise<ResultadoPesquisa | null> {
  cliente ??= new Anthropic();

  const dados = {
    nome: local.nome,
    endereco: local.endereco,
    categoria: local.categoria,
    notaGoogle: local.nota,
    avaliacoesGoogle: local.avaliacoes,
    nivelPreco: local.nivelPreco,
    site: local.site,
    telefone: local.telefone,
    distanciaKm: local.distanciaKm,
  };

  const mensagens: Anthropic.Beta.Messages.BetaMessageParam[] = [
    {
      role: "user",
      content: `O que o vendedor vende: ${oQueVende || "não informado"}
Tipo de cliente que ele procura: ${oQueProcura}

Dados do Google Maps sobre o possível cliente:
${JSON.stringify(dados, null, 2)}`,
    },
  ];

  let texto = "";
  // A busca na web pode pausar o turno (pause_turn); nesse caso continuamos de onde parou.
  for (let rodada = 0; rodada < 3; rodada++) {
    const resp = await cliente.beta.messages.create({
      model: "claude-opus-5-5",
      max_tokens: 8000,
      betas: ["server-side-fallback-2026-07-01"],
      fallbacks: "default",
      system: INSTRUCOES,
      output_config: { effort: "low" },
      tools: [{ type: "web_search_20260209", name: "web_search", max_uses: 3, user_location: { type: "approximate", country: "BR" } }],
      messages: mensagens,
    });

    if (resp.stop_reason === "refusal") return null;
    texto = resp.content
      .filter((b): b is Anthropic.Beta.Messages.BetaTextBlock => b.type === "text")
      .map((b) => b.text)
      .join("\n");

    if (resp.stop_reason !== "pause_turn") break;
    mensagens.push({ role: "assistant", content: resp.content });
  }

  const conferido = Resposta.safeParse(extrairJSON(texto));
  if (!conferido.success) return null;
  const r = conferido.data;

  return {
    psc: montarPSC(r.potencialVenda.pontos, r.informacoes.pontos, r.renda.pontos, r.interesse.pontos, [
      r.potencialVenda.motivo,
      r.informacoes.motivo,
      r.renda.motivo,
      r.interesse.motivo,
    ]),
    resumo: r.resumo,
    abordagem: r.abordagem,
    fontes: r.fontes.filter((f) => /^https?:\/\//.test(f)).slice(0, 5),
  };
}
