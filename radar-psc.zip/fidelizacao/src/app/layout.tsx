import type { Metadata } from "next";
import { Bricolage_Grotesque, Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const titulo = Bricolage_Grotesque({ subsets: ["latin"], variable: "--fonte-titulo", weight: ["500", "700", "800"] });
const texto = Inter({ subsets: ["latin"], variable: "--fonte-texto" });
const numeros = JetBrains_Mono({ subsets: ["latin"], variable: "--fonte-num", weight: ["500", "700"] });

export const metadata: Metadata = {
  title: "Radar PSC",
  description: "Encontre clientes no Google Maps, pesquise na internet e priorize pelo Percentual de Sucesso Comercial.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR">
      <body className={`${titulo.variable} ${texto.variable} ${numeros.variable}`}>{children}</body>
    </html>
  );
}
